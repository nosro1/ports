Copy here all files from the original game. The game requires assets
from the classic version released in 2002 (not the Definitive Edition, 2021).
Versions from Steam (no longer available to buy) and Rockstar Store
are confirmed to work fine.

If needed, readjust analog sticks sensitivity/deadzone by changing
[Left,Right]StickSens[X,Y] or [Left,Right]StickDeadzone values in reVC.ini.
